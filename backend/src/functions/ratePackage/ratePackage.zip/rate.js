"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
/* Provides metrics for uploaded packages.

Schema:
/package/{id}/rate:
    get:
      responses:
        200:
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/PackageRating'
          description: Return the rating. Only use this if each metric was computed
            successfully.
        400:
          description: There is missing field(s) in the PackageID
        403:
          description: Authentication failed due to invalid or missing AuthenticationToken.
        404:
          description: Package does not exist.
        500:
          description: The package rating system choked on at least one of the metrics.
      operationId: PackageRate
      summary: "Get ratings for this package. (BASELINE)"
    parameters:
    - name: id
      schema:
        $ref: '#/components/schemas/PackageID'
      in: path
      required: true
    - name: X-Authorization
      description: ""
      schema:
        $ref: '#/components/schemas/AuthenticationToken'
      in: header
      required: true
*/
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const index_1 = require("./src/index");
// Initialize DynamoDB client
const client = new client_dynamodb_1.DynamoDBClient({});
const dynamo = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
const TABLE_NAME = "PackageRegistry";
// Custom error class for better error handling
class PackageRegistryError extends Error {
    constructor(message, statusCode = 400) {
        super(message);
        this.name = "PackageRegistryError";
        this.statusCode = statusCode;
    }
}
const handler = async (event) => {
    var _a;
    try {
        // Validate HTTP method
        if (event.httpMethod !== "GET") {
            throw new PackageRegistryError("Method not allowed", 405);
        }
        // Validate path parameter for package ID
        const packageId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.id;
        if (!packageId) {
            throw new PackageRegistryError("Package ID is missing in the request", 400);
        }
        // Validate headers for X-Authorization
        const authToken = event.headers["X-Authorization"];
        if (!authToken) {
            throw new PackageRegistryError("Authentication failed: Missing AuthenticationToken", 403);
        }
        // Fetch the package from DynamoDB
        const { Item } = await dynamo.send(new lib_dynamodb_1.GetCommand({
            TableName: TABLE_NAME,
            Key: { id: packageId },
        }));
        if (!Item) {
            throw new PackageRegistryError(`Package with ID '${packageId}' does not exist`, 404);
        }
        if (!Item.url) {
            throw new PackageRegistryError("The package URL is missing", 500);
        }
        const metrics = await (0, index_1.main)(Item.url);
        // Check if metrics are available for the package
        if (!metrics) {
            throw new PackageRegistryError("The package rating system choked on at least one of the metrics", 500);
        }
        // Update the metrics in the DynamoDB table
        await dynamo.send(new lib_dynamodb_1.UpdateCommand({
            TableName: TABLE_NAME,
            Key: { id: packageId },
            UpdateExpression: "SET metrics = :metrics",
            ExpressionAttributeValues: {
                ":metrics": metrics,
            },
        }));
        // Return a successful response with the package rating
        return {
            statusCode: 200,
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                message: "Package rating retrieved successfully",
                metrics: metrics,
                details: metrics,
            }),
        };
    }
    catch (error) {
        console.error("Error:", error);
        // Determine error response
        let statusCode = 500;
        let message = "Internal Server Error";
        if (error instanceof PackageRegistryError) {
            statusCode = error.statusCode;
            message = error.message;
        }
        return {
            statusCode,
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                error: {
                    message,
                },
            }),
        };
    }
};
exports.handler = handler;
