"use strict";
/*
    This file is an example logical flow from a URL to
    fetching and parsing repo data and calculating some metrics
*/
Object.defineProperty(exports, "__esModule", { value: true });
exports.main = exports.runWorker = void 0;
//no writing to log files as lambda is read-only
require("dotenv/config");
const githubApi_1 = require("./api/githubApi");
const urlHandler_1 = require("./utils/urlHandler");
const worker_threads_1 = require("worker_threads");
const metricCalcs_1 = require("./metricCalcs");
// Function to create and manage worker threads
function runWorker(owner, repo, token, repoURL, repoData, metric) {
    return new Promise((resolve, reject) => {
        // PATH TO WORKER SCRIPT
        const worker = new worker_threads_1.Worker('./src/utils/worker.ts');
        // SEND DATA TO WORKER AND START THE WORKER
        worker.postMessage({ owner, repo, token, repoURL, repoData, metric });
        // GET THE WORKER'S RESULT
        worker.on('message', (result) => {
            resolve(result);
            worker.terminate();
        });
        // HANDLE ERRORS
        worker.on('error', (error) => {
            reject(error);
            worker.terminate();
        });
        // EXIT
        worker.on('exit', (code) => {
            if (code !== 0) {
                reject(new Error(`Worker stopped with exit code ${code}`));
            }
        });
    });
}
exports.runWorker = runWorker;
const main = async (url) => {
    const token = process.env.GITHUB_TOKEN || "";
    const inputURL = url;
    // Get repo details
    const repoDetails = await (0, urlHandler_1.getRepoDetails)(token, inputURL);
    const [owner, repo, repoURL] = repoDetails;
    // Fetch repository data from GitHub API
    const repoData = await (0, githubApi_1.fetchRepoData)(owner, repo, token);
    if (!repoData.data) {
        return null; // Return null or an appropriate error value
    }
    // Calculate all metrics (concurrently)
    const metrics = await (0, metricCalcs_1.calculateMetrics)(owner, repo, token, repoURL, repoData, inputURL);
    if (metrics == null) {
        return null; // Return null if metrics calculation fails
    }
    return metrics; // Return the calculated metrics at the end
};
exports.main = main;
