"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.calcResponsiveness = exports.calcResponsivenessScore = void 0;
const calcResponsivenessScore = (closedIssues, openIssues, pullRequests, sinceDate, isArchived) => {
    if (isArchived) {
        // repo is no longer maintained
        return 0.0;
    }
    let openIssueCount = 0;
    let closedIssueCount = 0;
    let openPRCount = 0;
    let closedPRCount = 0;
    for (let i = 0; i < Math.max(pullRequests.length, openIssues.length, closedIssues.length); ++i) {
        if (i < pullRequests.length && new Date(pullRequests[i].createdAt) >= sinceDate && !pullRequests[i].closedAt) {
            openPRCount++;
        }
        if (i < pullRequests.length && new Date(pullRequests[i].createdAt) >= sinceDate && pullRequests[i].closedAt) {
            closedPRCount++;
        }
        if (i < openIssues.length && new Date(openIssues[i].createdAt) >= sinceDate) {
            openIssueCount++;
        }
        if (i < closedIssues.length && new Date(closedIssues[i].createdAt) >= sinceDate) {
            closedIssueCount++;
        }
    }
    const totalRecentIssues = openIssueCount + closedIssueCount;
    const totalRecentPRs = openPRCount + closedPRCount;
    const issueCloseRatio = totalRecentIssues > 0
        ? closedIssueCount / totalRecentIssues
        : 0.0;
    const prCloseRatio = totalRecentPRs > 0
        ? closedPRCount / totalRecentPRs
        : 0.0;
    return 0.5 * issueCloseRatio + 0.5 * prCloseRatio;
};
exports.calcResponsivenessScore = calcResponsivenessScore;
function calcResponsiveness(repoData) {
    var _a, _b, _c, _d;
    const recentPullRequests = (_a = repoData.data) === null || _a === void 0 ? void 0 : _a.data.repository.pullRequests;
    const isArchived = (_b = repoData.data) === null || _b === void 0 ? void 0 : _b.data.repository.isArchived;
    const totalOpenIssues = (_c = repoData.data) === null || _c === void 0 ? void 0 : _c.data.repository.openIssues;
    const totalClosedIssues = (_d = repoData.data) === null || _d === void 0 ? void 0 : _d.data.repository.closedIssues;
    const oneMonthAgo = new Date();
    oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
    if (!(recentPullRequests === null || recentPullRequests === void 0 ? void 0 : recentPullRequests.nodes) || !(totalClosedIssues === null || totalClosedIssues === void 0 ? void 0 : totalClosedIssues.nodes) || !(totalOpenIssues === null || totalOpenIssues === void 0 ? void 0 : totalOpenIssues.nodes)) {
        return -1.0;
    }
    const responsiveness = (0, exports.calcResponsivenessScore)(totalClosedIssues.nodes, totalOpenIssues.nodes, recentPullRequests.nodes, oneMonthAgo, isArchived !== null && isArchived !== void 0 ? isArchived : false);
    return responsiveness;
}
exports.calcResponsiveness = calcResponsiveness;
