"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.calcCorrectness = exports.calcCorrectnessScore = void 0;
const calcCorrectnessScore = (totalOpenIssuesCount, totalClosedIssuesCount) => {
    const totalIssues = totalOpenIssuesCount + totalClosedIssuesCount;
    if (totalIssues == 0) {
        return 1.0;
    }
    return totalClosedIssuesCount / totalIssues;
};
exports.calcCorrectnessScore = calcCorrectnessScore;
function calcCorrectness(repoData) {
    var _a, _b;
    const totalOpenIssues = (_a = repoData.data) === null || _a === void 0 ? void 0 : _a.data.repository.openIssues;
    const totalClosedIssues = (_b = repoData.data) === null || _b === void 0 ? void 0 : _b.data.repository.closedIssues;
    if (!totalOpenIssues || !totalClosedIssues) {
        return -1.0;
    }
    const correctness = (0, exports.calcCorrectnessScore)(totalOpenIssues.totalCount, totalClosedIssues.totalCount);
    return correctness;
}
exports.calcCorrectness = calcCorrectness;
