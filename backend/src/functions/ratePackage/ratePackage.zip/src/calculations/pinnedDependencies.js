"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.calcPinnedDependencies = void 0;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
async function calcPinnedDependencies(owner, repo, token) {
    const packageJsonPath = path.join("./repos", `${owner}_${repo}`, 'package.json');
    if (!fs.existsSync(packageJsonPath)) {
        return 1.0; // No dependencies, so return 1.0
    }
    const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
    const dependencies = Object.assign(Object.assign({}, packageJson.dependencies), packageJson.devDependencies);
    const totalDependencies = Object.keys(dependencies).length;
    if (totalDependencies === 0) {
        return 1.0;
    }
    let pinnedCount = 0;
    for (const dep in dependencies) {
        const version = dependencies[dep];
        const majorMinorPattern = /^\d+\.\d+/; // Matches major.minor version (e.g., 2.3.X)
        if (majorMinorPattern.test(version)) {
            pinnedCount++;
        }
    }
    return pinnedCount / totalDependencies;
}
exports.calcPinnedDependencies = calcPinnedDependencies;
;
