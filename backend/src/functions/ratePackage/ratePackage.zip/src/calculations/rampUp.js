"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.calcRampUp = void 0;
const githubApi_1 = require("../api/githubApi");
async function calcRampUp(repoData) {
    var _a;
    const readmeKeys = [
        'READMEMD', 'READMENOEXT', 'READMETXT', 'READMERDOC', 'READMEHTML', 'READMEADOC',
        'READMEMARKDOWN', 'READMEYAML', 'READMERST', 'READMETEXTILE', 'readmemd',
        'readmenoext', 'readmetxt', 'readmerdoc', 'readmehtml', 'readmeadoc',
        'readmemarkdown', 'readmeyaml', 'readmerst', 'readmetextile', 'readMemd',
        'readMenoext', 'readMetxt', 'readMerdoc', 'readMehtml', 'readMeadoc',
        'readMemarkdown', 'readMeyaml', 'readMerst', 'readMetextile', 'ReadMemd',
        'ReadMenoext', 'ReadMetxt', 'ReadMerdoc', 'ReadMehtml', 'ReadMeadoc',
        'ReadMemarkdown', 'ReadMeyaml', 'ReadMerst', 'ReadMetextile', 'Readmemd',
        'Readmenoext', 'Readmetxt', 'Readmerdoc', 'Readmehtml', 'Readmeadoc',
        'Readmemarkdown', 'Readmeyaml', 'Readmerst', 'Readmetextile'
    ];
    const examplesKeys = ['examplesFolder', 'exampleFolder', 'ExamplesFolder', 'ExampleFolder'];
    const repository = (_a = repoData.data) === null || _a === void 0 ? void 0 : _a.data.repository;
    // Find the README content
    let readMe = readmeKeys.map(key => repository === null || repository === void 0 ? void 0 : repository[key]).find(readme => readme === null || readme === void 0 ? void 0 : readme.text);
    // Find the examples folder
    let exFolder = examplesKeys.map(key => repository === null || repository === void 0 ? void 0 : repository[key]).find(folder => folder != null);
    // Set rampUp value
    let rampUp = (readMe === null || readMe === void 0 ? void 0 : readMe.text) ? await (0, githubApi_1.getReadmeDetails)(readMe.text, exFolder) : 0.9;
    return rampUp;
}
exports.calcRampUp = calcRampUp;
