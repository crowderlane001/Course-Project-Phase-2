"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.calcReviewedCode = void 0;
async function calcReviewedCode(repoData) {
    var _a, _b;
    const pullRequests = ((_a = repoData.data) === null || _a === void 0 ? void 0 : _a.data.repository.pullRequests.nodes) || [];
    let totalPRs = 0;
    let reviewedPRs = 0;
    for (const pr of pullRequests) {
        totalPRs++;
        if (((_b = pr.reviews) === null || _b === void 0 ? void 0 : _b.totalCount) > 0) {
            reviewedPRs++;
        }
    }
    if (totalPRs === 0) {
        return 1.0; // No PRs, return full score
    }
    return reviewedPRs / totalPRs;
}
exports.calcReviewedCode = calcReviewedCode;
;
