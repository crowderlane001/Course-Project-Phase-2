"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.calcBusFactor = exports.calcBusFactorScore = void 0;
const githubApi_1 = require("../api/githubApi");
const calcBusFactorScore = (contributorActivity) => {
    if (!contributorActivity) {
        return 0.0;
    }
    let totalCommits = 0;
    let totalContributors = 0;
    for (const contributor of contributorActivity) {
        totalCommits += contributor.total;
        ++totalContributors;
    }
    const threshold = Math.ceil(totalCommits * 0.5); // 50% of commits
    let curr = 0;
    let busFactor = 0;
    // contributorActivity default sorting is least to greatest, so iterate R to L 
    for (let i = contributorActivity.length - 1; i >= 0; i--) {
        curr += contributorActivity[i].total;
        busFactor++;
        if (curr >= threshold) {
            break;
        }
    }
    const averageBusFactor = 3;
    // if bus factor is 10+, thats more than enough
    if (busFactor > 9) {
        return 1.0;
    }
    // scale bus factor values using sigmoid function
    return 1.0 - Math.exp(-(busFactor ** 2) / (2 * averageBusFactor ** 2));
};
exports.calcBusFactorScore = calcBusFactorScore;
async function calcBusFactor(owner, repo, token) {
    let busFactor;
    const contributorActivity = await (0, githubApi_1.fetchContributorActivity)(owner, repo, token);
    if (!(contributorActivity === null || contributorActivity === void 0 ? void 0 : contributorActivity.data) || !Array.isArray(contributorActivity.data)) {
        busFactor = -1.0;
    }
    else {
        busFactor = (0, exports.calcBusFactorScore)(contributorActivity.data);
    }
    return busFactor;
}
exports.calcBusFactor = calcBusFactor;
