"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchGithubUrlFromNpm = void 0;
const apiUtils_1 = require("./apiUtils");
const NPM_BASE_URL = "https://registry.npmjs.org";
const fetchGithubUrlFromNpm = async (packageName) => {
    const url = `${NPM_BASE_URL}/${packageName}`;
    const response = await (0, apiUtils_1.apiGetRequest)(url);
    if (response.error || !response.data || !response.data.repository || !response.data.repository.url) {
        return { data: null, error: 'Repository URL not found' };
    }
    let repoUrl = response.data.repository.url.replace(/^git\+/, '').replace(/\.git$/, '');
    if (repoUrl.startsWith('ssh://')) {
        repoUrl = repoUrl.replace('ssh://git@', 'https://');
    }
    else if (repoUrl.startsWith('git@')) {
        repoUrl = repoUrl.replace('git@', 'https://').replace('.com:', '.com/');
    }
    else if (repoUrl.startsWith('git://')) {
        repoUrl = repoUrl.replace('git://', 'https://');
    }
    return { data: repoUrl, error: null };
};
exports.fetchGithubUrlFromNpm = fetchGithubUrlFromNpm;
