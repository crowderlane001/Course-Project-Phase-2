"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.apiPostRequest = exports.apiGetRequest = void 0;
const axios_1 = __importDefault(require("axios"));
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
const apiGetRequest = async (url, token, retries = 10, retryDelay = 2000) => {
    var _a, _b, _c, _d, _e, _f;
    try {
        const config = {
            headers: Object.assign({ 'Content-Type': 'application/json' }, (token ? { 'Authorization': `Bearer ${token}` } : {})),
        };
        let response = await axios_1.default.get(url, config);
        if (response.status === 202 && retries > 0) {
            await delay(retryDelay);
            return await (0, exports.apiGetRequest)(url, token, retries - 1, retryDelay);
        }
        return { data: response.data, error: null };
    }
    catch (error) {
        // Check for 404 error and specific GitHub License API documentation URL
        if (((_a = error.response) === null || _a === void 0 ? void 0 : _a.status) === 404 && ((_c = (_b = error.response) === null || _b === void 0 ? void 0 : _b.data) === null || _c === void 0 ? void 0 : _c.documentation_url) === 'https://docs.github.com/rest/licenses/licenses#get-the-license-for-a-repository') {
            console.warn('No license found for this repository.');
            return { data: null, error: "Not Found" };
        }
        console.error('Error details:', ((_d = error.response) === null || _d === void 0 ? void 0 : _d.data) || error.message || error);
        return { data: null, error: ((_f = (_e = error.response) === null || _e === void 0 ? void 0 : _e.data) === null || _f === void 0 ? void 0 : _f.message) || error.message || 'Something went wrong' };
    }
};
exports.apiGetRequest = apiGetRequest;
const apiPostRequest = async (url, data, token) => {
    var _a, _b, _c;
    try {
        const config = {
            headers: Object.assign({ 'Content-Type': 'application/json' }, (token ? { 'Authorization': `Bearer ${token}` } : {})),
        };
        const response = await axios_1.default.post(url, data, config);
        return { data: response.data, error: null };
    }
    catch (error) {
        console.error('Error details:', ((_a = error.response) === null || _a === void 0 ? void 0 : _a.data) || error.message || error);
        return { data: null, error: ((_c = (_b = error.response) === null || _b === void 0 ? void 0 : _b.data) === null || _c === void 0 ? void 0 : _c.message) || error.message || 'Something went wrong' };
    }
};
exports.apiPostRequest = apiPostRequest;
