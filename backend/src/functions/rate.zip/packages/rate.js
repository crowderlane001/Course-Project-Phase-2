"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
/* Provides metrics for uploaded packages.

Schema:
/package/{id}/rate:
    get:
      responses:
        200:
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/PackageRating'
          description: Return the rating. Only use this if each metric was computed
            successfully.
        400:
          description: There is missing field(s) in the PackageID
        403:
          description: Authentication failed due to invalid or missing AuthenticationToken.
        404:
          description: Package does not exist.
        500:
          description: The package rating system choked on at least one of the metrics.
      operationId: PackageRate
      summary: "Get ratings for this package. (BASELINE)"
    parameters:
    - name: id
      schema:
        $ref: '#/components/schemas/PackageID'
      in: path
      required: true
    - name: X-Authorization
      description: ""
      schema:
        $ref: '#/components/schemas/AuthenticationToken'
      in: header
      required: true
*/
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
// Initialize DynamoDB client
const client = new client_dynamodb_1.DynamoDBClient({});
const dynamo = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
const TABLE_NAME = "PackageRegistry";
// Custom error class for better error handling
class PackageRegistryError extends Error {
    constructor(message, statusCode = 400) {
        super(message);
        this.name = "PackageRegistryError";
        this.statusCode = statusCode;
    }
}
const handler = async (event) => {
    var _a;
    try {
        // Validate HTTP method
        if (event.httpMethod !== "GET") {
            throw new PackageRegistryError("Method not allowed", 405);
        }
        // Validate path parameters
        const packageId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.id;
        if (!packageId) {
            throw new PackageRegistryError("Package ID is required", 400);
        }
        // Validate headers
        const authToken = event.headers["X-Authorization"];
        if (!authToken) {
            throw new PackageRegistryError("Authentication token is missing", 403);
        }
        // Verify package data in DynamoDB
        const { Item } = await dynamo.send(new lib_dynamodb_1.GetCommand({
            TableName: TABLE_NAME,
            Key: { id: packageId },
        }));
        if (!Item) {
            throw new PackageRegistryError(`Package with ID '${packageId}' not found`, 404);
        }
        // Validate metrics exist
        if (Item.metrics == null) {
            throw new PackageRegistryError("Package metrics are incomplete", 500);
        }
        // Return the rating (assuming the rating is precomputed in the `metrics` field)
        return {
            statusCode: 200,
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                message: "Package rating retrieved successfully",
                rating: Item.metrics.rating,
                details: Item.metrics, // Include full metrics if needed
            }),
        };
    }
    catch (error) {
        if (error instanceof Error) {
            console.error("Error:", {
                message: error.message,
                stack: error.stack,
                name: error.name,
            });
        }
        else {
            console.error("Unknown error:", error);
        }
        // Handle errors
        let statusCode = 500;
        let message = "Internal Server Error";
        if (error instanceof PackageRegistryError) {
            statusCode = error.statusCode;
            message = error.message;
        }
        return {
            statusCode,
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                error: {
                    message,
                },
            }),
        };
    }
};
exports.handler = handler;
